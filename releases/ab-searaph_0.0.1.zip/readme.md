# AB-Searaph: Custom AngelBob+Seablock Modpack for Factorio

A custom modpack for Factorio focusing primarily on the major modpacks from [Arch666Angel](https://mods.factorio.com/user/Arch666Angel) and [Bobingabout](https://mods.factorio.com/user/bobingabout) with the [Seablock extension](https://mods.factorio.com/mod/SeaBlock) (shortened to AB+C or ABC). So far, this has no purposeful direction, merely being a plaything as we seek to integrate various mods such as [Cargo Ships](https://mods.factorio.com/mod/cargo-ships) and [Logistic Carts](https://mods.factorio.com/mod/logicarts).

## Main Features

* Replace Coal with Charcoal in Recipes.
