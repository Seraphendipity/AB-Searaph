-- settings.lua

data:extend({
    {
		-- Replace coal with charcoal in recipes
        type = "bool-setting",
        name = "ab-searaph-coal-replace",
        setting_type = "startup",
        default_value = true
    }
})